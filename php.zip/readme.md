# PHP

[Installation XAMMP](https://www.apachefriends.org/fr/download.html)

Les fichiers **php** se trouvent dans le dossier `c:/xampp/htdocs`

[PHP documentation](https://www.php.net/manual/fr/)
