<?php
define('DBHOST', 'localhost');
define('DBNAME', 'notes');
define('DBUSERNAME', 'root');
define('DBUSERPASSWORD', '');
define('DBCHARSET', 'utf8mb4');
