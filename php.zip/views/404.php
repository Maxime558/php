<?php require 'partials/header.php'; ?>

<title>404 ERROR</title>
<h1>Erreur 404 !</h1>

<?php require 'partials/footer.php'; ?>