<?php
require 'config/fonction.php';
require 'core/routeur.php';