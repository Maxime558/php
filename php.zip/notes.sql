-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 16 nov. 2023 à 09:18
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `notes`
--
CREATE DATABASE IF NOT EXISTS `notes` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `notes`;

-- --------------------------------------------------------

--
-- Structure de la table `note`
--

CREATE TABLE `note` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `note`
--

INSERT INTO `note` (`id`, `title`, `content`, `created_at`, `user_id`, `file_name`) VALUES
(8, 'udtudud', 'udtufdu', '2023-10-24 08:03:12', 5, NULL),
(10, 'ysysydrs', 'sdyysys', '2023-10-24 08:03:12', 5, NULL),
(32, 'fgugrug', 'gufigifg', '2023-10-25 10:05:27', 4, NULL),
(33, 'uhguifriu', 'frierhkj', '2023-10-25 10:05:27', 5, NULL),
(34, 'iugeigfrg', 'test', '2023-10-25 10:05:27', 5, NULL),
(35, 'eidhoeihrefg', 'ijhiuhgdiuehg', '2023-10-25 10:05:27', 5, NULL),
(70, 'Ajout d&#039;un gif', 'Test d&#039;un giiiiif', '2023-11-13 09:12:36', 13, 'giphy.gif'),
(71, 'ytrdtrds', 'ytdydyd', '2023-11-13 14:03:38', 990, '260-200x300.jpg'),
(72, 'iudidti', 'tstrdtrdty', '2023-11-13 14:03:51', 994, '505-200x300.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`user_id`, `name`, `email`, `password`, `is_admin`) VALUES
(1, 'Isabella', 'Isabella@gmail.com', '$2y$10$R.WFbOfXhqHupmLXWs.3s.IUr7aDK0kOhjI5t0WP044ZNwb5xed.C', 0),
(2, 'April', 'april.peterson@hotmail.com', NULL, 0),
(4, 'Brent', 'brent.jimenez@example.com', NULL, 0),
(5, 'Erica', 'erica.rodriguez@example.com', NULL, 0),
(13, 'Jean', 'Jean@outlook.com', NULL, 0),
(990, 'Sondra', 'nettie1992@gmail.com', NULL, 0),
(991, 'Kenzi', 'kenzi.walters@example.com', NULL, 0),
(992, 'Felecia', 'felecia.black@gmail.com', NULL, 0),
(993, 'Isobel', 'isobel.wood@example.com', '$2y$10$SYgPF1jPoamcnc3WzkQxf.8kRYEMjM26fi7jzZ0vgD5xwGz8.edXK', 0),
(994, 'Kay', 'kay.graham@example.com', '$2y$10$dFyz40UlwXtwqnyqlJ8zN.SHCMZo0bxnIgrjvZY6007BBfXaBFLBW', 0),
(995, 'Admin', 'admin@gmail.com', '$2y$10$8gFjawtXYBLBhNGXzLum/uwyqHkEZgRjrvy90pDbx5T.LSzzaI9pu', 1),
(996, 'Tracy', 'tracy.cunningham@example.com', '$2y$10$of7Kg.s.GsJrWxtAKZFHvOEKiriJZ3uFWcmmuf.2pAuZJRVwprWSC', 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `note`
--
ALTER TABLE `note`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id` (`user_id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `note`
--
ALTER TABLE `note`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=997;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `note`
--
ALTER TABLE `note`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
